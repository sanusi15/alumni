<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Data Alumni SMK N 1 Anyer Tahun Angkatan </title>
    <style>
        body {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif
        }

        .container {
            padding: 5px 10px;
        }

        .header {}

        .header .date-detail {
            float: right;
            font-size: 10px;
        }

        .title p:first-child {
            font-size: 14px;
            font-weight: bold;
        }

        .title p:last-child {
            font-size: 13px;
            font-weight: 400;
        }

        .table {
            border-collapse: collapse;
            width: 100%;
        }

        .table thead tr td {
            border: 1px solid #000;
            padding: 2px 5px;
            font-weight: 500;
            font-size: 11px;
        }

        .table tbody tr td {
            border: 1px solid #000;
            padding: 0 5px;
            font-size: 10px;
        }

        .table tbody tr td:nth-child(3) {
            width: 20%;
        }

        .table tbody tr td:nth-child(5) {
            width: 20%;
        }

        .footer {
            position: absolute;
            bottom: 0;
            right: 0;
            margin-bottom: 50px;
            margin-right: 20px;
        }

        .footer table {
            border: none;
            text-align: center;
            font-size: 13px;
        }

        .footer table tr td {
            padding: 20px 0;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <div class="date-detail">Printed on <?= date('Y-m-d') ?> By Admin</div>
        </div>
        <div class="title">
            <p>Data Alumni SMK N 1 Anyer</p>
            <p>Tahun Angkatan : <?= $tahunAngkatan['tahun'] ?></p>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <td>No</td>
                    <td>No Alumni</td>
                    <td>Nama Siswa</td>
                    <td>NISN</td>
                    <td>Jurusan</td>
                    <td>TTL</td>
                    <td>Email</td>
                    <td>Kontak</td>
                    <td>Alamat</td>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;
                foreach ($data as $row) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $row['no_alumni'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['nisn'] ?></td>
                        <td><?= $row['nama_jurusan'] ?></td>
                        <td><?= $row['tempat_lahir'] ?>, <?= $row['tanggal_lahir'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['kontak'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="footer">
            <table>
                <tr>
                    <td>Mengetahui</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td><u>Kepala Sekolah</u></td>
                </tr>
            </table>
        </div>
    </div>
</body>

</html>